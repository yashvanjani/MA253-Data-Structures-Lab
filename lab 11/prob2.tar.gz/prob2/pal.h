void pal(int,char*, int&, int*&);
