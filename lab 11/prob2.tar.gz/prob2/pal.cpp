#include "pal.h"

//Implement pal(). See pal.h for declaration of pal()
// write your code here
