void lis(int,int*, int&, int*&);
