#include "lis.h"

//Implement lis(). See 'lis.h' for declaration of lis()
// write your code here
