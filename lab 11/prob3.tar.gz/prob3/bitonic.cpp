#include "bitonic.h"

//Implement function 'bitonic()'. It is declared in 'bitonic.h'
// write your code here
