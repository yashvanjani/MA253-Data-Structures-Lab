#ifndef BITONIC
#define BITONIC 1
#include <cmath>
using namespace std;

struct point {int x,y;};
void bitonic(int,point[],bool[]);
double d(point,point);
#endif
