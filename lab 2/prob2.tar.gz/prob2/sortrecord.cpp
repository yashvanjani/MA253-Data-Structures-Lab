//Include header for string handling
#include <string>
#include "sortrecord.h"
using namespace std;

//Define the 'sort' function that you declared in 'sortrecord.h' header.
//Use insertion sort algorithm.

// write your code here
