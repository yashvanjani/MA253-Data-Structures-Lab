#include "stack.h"

//Define all the member functions (except show()) of class 'stack'
// which are declared in header file 'stack.h'

// write your code here
