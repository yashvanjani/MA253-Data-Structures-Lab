#ifndef OTHER_H
#define OTHER_H 1
void draw(rbtree&);
#endif
