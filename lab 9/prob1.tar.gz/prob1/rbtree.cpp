#include "rbtree.h"

rbtree::rbtree(void)
{
        nil = new node;
        nil->left = nil;
        nil->right = nil;
        nil->p = nil;
        nil->color = BLACK;
        root = nil;
}

//Implement the following member functions of `rbtree` class
//	void LeftRotate(node*);
//	void RightRotate(node*);
//	void RBInsert(node*);
//	void RBInsertFixup(node*);


// write your code here
