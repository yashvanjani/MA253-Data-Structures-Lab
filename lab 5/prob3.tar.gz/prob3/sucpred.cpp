#include "bst.h"
#include <iostream>
using namespace std;

void bst::InorderTreeWalk(node *x)
{
	if(x!=NULL)
	{
		InorderTreeWalk(x->left);
		cout<<x->key<<" "<<x->sat<<endl;
		InorderTreeWalk(x->right);
	}
}


//Implement TreeSearch(), TreeMinimum(), TreeMaximum()
// , TreePrdecessor() and TreeSuccessor() as declared in 'bst.h'
//In prob1 and prob2 you have already written code for
//   TreeSearch(), TreeMinimum() and  TreeMaximum()
//You need to write that code again here. 
// write your code here
