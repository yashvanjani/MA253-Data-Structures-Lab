#include "bst.h"
#include <iostream>
using namespace std;

void bst::InorderTreeWalk(node *x)
{
	if(x!=NULL)
	{
		InorderTreeWalk(x->left);
		cout<<x->key<<" "<<x->sat<<endl;
		InorderTreeWalk(x->right);
	}
}

//Implement TreeMinimum() and TreeMaximum()
// as declared in 'bst.h' 
// write your code here
