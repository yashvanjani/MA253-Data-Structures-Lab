struct node
{
	int key;
	float sat;
	node *left, *right, *p;
};
