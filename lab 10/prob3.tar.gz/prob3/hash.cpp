#include "hash.h"

hash::hash(int size)
{
	m = size;
	T = new int[m];
	for(int i=0;i<m;i++) T[i]=NIL;
}

//Implement HashSearch(), HashInsert(), HashDelete() for open addressing
//Implement hash function h() which uses double hashing with
// auxiliary hash functions h1(k)=k and h2(k)=1+(k mod (m-1))

// write your code here
