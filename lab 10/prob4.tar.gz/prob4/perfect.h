#include <cstdlib>

struct hparam {int a,b;};
hparam f1(int,int,int,int*);
hparam f2(int,int,int,int*);

