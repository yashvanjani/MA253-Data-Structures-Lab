#include "perfect.h"
#include <cstdlib>

// write your code here
