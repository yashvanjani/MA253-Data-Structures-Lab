#include "hash.h"

hash::hash(int size)
{
	m = size;
	T = new int[m];
	for(int i=0;i<m;i++) T[i]=NIL;
}

//Implement HashSearch(), HashInsert(), HashDelete() for open addressing
//Implement hash function h() which uses linear probing with
// auxiliary hash function h'(k)=k

// write your code here
