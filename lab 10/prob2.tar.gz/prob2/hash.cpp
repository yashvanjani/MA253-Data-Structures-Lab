#include "hash.h"

hash::hash(int size)
{
	m = size;
	T = new int[m];
	for(int i=0;i<m;i++) T[i]=NIL;
}

//Implement HashSearch(), HashInsert(), HashDelete() for open addressing
//Implement hash function h() which uses quadratic probing with
// auxiliary hash function h'(k)=k,
// c1 = 1 and c2 = 3 (See Cormen 3rd Ed. Excercise 11.4-1)

// write your code here
