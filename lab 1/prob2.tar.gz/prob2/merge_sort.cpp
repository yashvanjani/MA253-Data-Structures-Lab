#include "merge_sort.h"

void merge_sort(int A[],int p, int r)
{
// write your code here
}

void merge(int A[],int p, int q,int r)
{
// write your code here
}
