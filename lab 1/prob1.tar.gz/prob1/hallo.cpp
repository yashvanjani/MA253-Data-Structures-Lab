#include <iostream>
using namespace std;

int main()
{
// write your code here
	return 0;
}
