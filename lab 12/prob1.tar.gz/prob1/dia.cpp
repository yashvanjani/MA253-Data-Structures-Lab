#include "dia.h"
//Implement function dia()
// write your code here
