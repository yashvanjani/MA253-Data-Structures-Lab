int dia(int, int, int [][2]);
