void toposort(int, int, int [][2], int[]);
