#include "qsort.h"
using namespace std;

//Define the functions 'quicksort' and 'partition'
//These functions are declared in 'qsort.h' header.
//Read the 'qsort.h' file (but do not modify it) to know what should be the
// return-type, argument-type and number of arguments of these functions
// Define the functions accordingly.

// write your code here
