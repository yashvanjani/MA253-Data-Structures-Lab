#include "list.h"
using namespace std;

//Implement the member functions insert_after()
//Code for push_front() should give you some idea.
// push_front(x) is a special case of insert_after(m,x) where 'm' is 's'
// write your code here


//Implement the member functions insert_sorted()
//To insert an integer 'v' 
// find the pointer 't' to the last node whose data is < 'v'
// (if no such node exists then 't' should point to the sentinel)
// then insert_after(t,v);
// write your code here
