#include "heap.h"

heap::heap(int s)
{
	A = new int[s]; heap_size=0; length=s;
}

//Implement the following functions
//
//int Parent(int)
//int Child(int,int)
//void heap::MinHeapify(int)
//void heap::BuildMinHeap(void)
//void heap::Heapsort(void)

// write your code here
